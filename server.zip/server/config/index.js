// 数据库的配置，node 想要链接 mysql 数据库，
// 需要知道数据库的账号，密码 和数据库的名字，还有数据库的端口号

const dataBase = {
  DATABASE: 'studymaster',
  USERNAME: 'root',
  PASSWORD: 'root',
  PORT: '3306',
  HOST: 'localhost'
}

module.exports = dataBase

